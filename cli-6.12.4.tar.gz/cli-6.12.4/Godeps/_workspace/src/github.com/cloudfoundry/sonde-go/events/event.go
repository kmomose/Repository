package events

type Event interface {
	ProtoMessage()
}
